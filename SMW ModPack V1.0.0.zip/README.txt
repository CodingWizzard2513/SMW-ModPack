;===================================================================================================================================
; SMW Modpack
;	By Coding_Wizzard
;
;  An asm code pack which allows for the injection of mischallanous codes.
;  To sucsessfully install, please follow the istructions below.
;===================================================================================================================================	
;                           						File List
;===================================================================================================================================
; 				                                "modpack_defs.asm"
; 				                                   "modpack.asm"
;							         "Music_Patches.asm"
; 				                                    "README.txt"
;===================================================================================================================================
;                                    			     Instructions
;===================================================================================================================================
;						Warning: if the following instructions are not performed right, there is a chance that this patch can corrupt your rom.
;
; 1. To Install, open your fresh, new SMW rom in Lunar Magic. Goto file > Expand Rom > and then expandyour rom to at least 2mb.
; 2. Then, save your rom and close out of lunar magic. 
; 3. Next, open the "modpack_defs.asm" file in notepad and configure (Configuaration instructions inside). Remember to set "!iRead" to one or the patch won't work. 
; 4. If you want to use the music mods, also configure the "Important Music Settings" in the same file.
; 5. Save the file and close out of notepad. Launch Asar and patch your rom with the file "modpack.asm".
; 6. If you are using the music mods and are not using AddmusicK, Launch asar and patch your rom with "Music_Patches.asm".
; Congratulations! You have sucsessfully installed SMW ModPack. Have fun!
;===================================================================================================================================